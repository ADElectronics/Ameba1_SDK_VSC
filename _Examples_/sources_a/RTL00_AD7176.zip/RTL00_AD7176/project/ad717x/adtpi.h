/*
*
*
 */
#ifndef ADTPI
#define ADTPI

#include "device.h"
#include "FreeRTOS.h"
#include "task.h"
#include <stdio.h>
#ifdef CONFIG_RTL8195A
#include "rtl8195a/rtl_libc.h"
int c_printf(const char *fmt, ...);
#endif
#define AVG_COUNT 32

#define CONV_TIMEOUT_MS 250 // 5 sps
#define CH0 0
#define CH1 1
#define CH2 2
#define CH3 3
#define V_REF 4.096
#define COUNTS_MAX 16777216 //2^24
#define M_BIT 24
#define V_OFFS 2.048
#define INPUT_GAIN 2.68

#define LOG10_2 0.30103

//#define CONVERT_COUNTS 1 //uncomment to convert counts to physical value 

//SERVER related definitions:
#define LISTEN_PORT 7176
#define CLIENT_MSG_LENGTH 70

typedef struct _stats_type
{
	double avg;
	double std;
	double enob;
}stats_type;

//delta_Vin = -Vref...+Vref --> delta_Vin_pp = 2*Vref
//counts = (Vref + delta_Vin)*(2^24)/(2*Vref)
//delta_Vin = (2*counts/(2^24) - 1)*Vref
//delta_Vin = (Vin - Voffs)*Ginput
//Vin = delta_Vin/Ginput + Voffs
#endif 
