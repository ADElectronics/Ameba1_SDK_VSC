#ifndef _COMMUNICATION_H_
#define _COMMUNICATION_H_

int init_drv_ad717x(void);
void deinit_drv_ad717x(void);
int start_ad717x_conversion(int no_start);

int32_t _AD717X_SPI_Read(uint8_t* buf, uint32_t buflength);
int32_t _AD717X_SPI_Write(uint8_t* buf, uint32_t buflength);
#define AD717X_SPI_Read(id, buf, len) _AD717X_SPI_Read(buf, len)
#define AD717X_SPI_Write(id, buf, len) _AD717X_SPI_Write(buf, len)

#endif // _COMMUNICATION_H_
