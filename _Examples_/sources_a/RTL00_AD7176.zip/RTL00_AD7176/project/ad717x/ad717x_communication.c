#include "adtpi.h"
#include "ad717x_communication.h"

#include "hal_gpio.h"
#include "bitband_io.h"
#include "spi_api.h"
#include "spi_ex_api.h"

#if defined(CONFIG_RTL8195A)
#define AD717X_SPI_SPEED 10000000 //10416666
#define AD717X_SPI_MOSI  PC_2
#define AD717X_SPI_MISO  PC_3
#define AD717X_SPI_SCLK  PC_1
#define AD717X_PIN_CS    PA_2 // PC_0
#define AD717X_PIN_SYN	 PA_1
#define AD717X_PIN_RDY	 PA_0 //paraleli SPI_MISO, AD7176 DOUT
#elif defined(RTL8711BN)
#define AD717X_SPI_SPEED 5000000
#define AD717X_SPI_MOSI  PC_23
#define AD717X_SPI_MISO  PC_22
#define AD717X_SPI_SCLK  PC_18
#define AD717X_PIN_CS    PA_19 // PA_0
#define AD717X_PIN_SYN	 PA_5
#define AD717X_PIN_RDY	 PA_12 //paraleli SPI DOUT
#endif

//////////////////////////////////////////////////////////////////////////////////
volatile uint8_t * p_dpinSyn; // direct (output): =0 -> input, =1 -> output
volatile uint8_t * p_opinCs; // output
volatile uint8_t * p_ipinRdy; // input

#define gpioDirSyn(x) *p_dpinSyn = x // =0 -> input, =1 -> output
#define gpioOutSyn(x) *p_dpinSyn = (x) == 0 // =0 -> input, =1 -> output
#define gpioOutCs(x) *p_opinCs = x
#define gpioReadRdy(x) (*p_ipinRdy)
//////////////////////////////////////////////////////////////////////////////////
spi_t spi_master;
//////////////////////////////////////////////////////////////////////////////////
int init_drv_ad717x(void)
{
     p_dpinSyn = HardSetPin(AD717X_PIN_SYN, DOUT_OPEN_DRAIN, 0) + 4*32; // DOUT_PUSH_PULL? Set as output, 0
     p_opinCs = HardSetPin(AD717X_PIN_CS, DOUT_PUSH_PULL, 0);
     HardSetPin(AD717X_PIN_RDY, DIN_PULL_HIGH, 1); // Set as input.
     p_ipinRdy = GetInPinBitBandAddr(AD717X_PIN_RDY);

     if (p_dpinSyn == NULL || p_opinCs == NULL || p_ipinRdy == NULL) {
    	 return -1;
   	 }

 	 spi_init(&spi_master, AD717X_SPI_MOSI, AD717X_SPI_MISO, AD717X_SPI_SCLK, AD717X_PIN_CS); // CS заданный тут нигде не используется
     spi_format(&spi_master, 8, 0, 0);
     spi_frequency(&spi_master, AD717X_SPI_SPEED);
//     spi_slave_select(&spi_master, ssn); // выбор CS

     gpioOutSyn(1);
     gpioOutCs(0);
     return 0;
}
//////////////////////////////////////////////////////////////////////////////////
void deinit_drv_ad717x(void)
{
	gpioOutCs(1);
	spi_free(&spi_master);
}
//////////////////////////////////////////////////////////////////////////////////
int start_ad717x_conversion(int no_start)
{
	if(no_start == 0) {
		// lo-hi edge initiates conv.
		gpioOutSyn(0);
		gpioOutSyn(1);
	}
	uint32_t tt = xTaskGetTickCount();
	while(gpioReadRdy()) {
		if(xTaskGetTickCount() - tt > CONV_TIMEOUT_MS) {
			return -3; // TIMEOUT
		}
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
int32_t _AD717X_SPI_Write(uint8_t* buf, uint32_t buflength)
{
	if (spi_master_write_stream(&spi_master, (char*)buf, buflength) != HAL_OK)
		return -4;
	spi_flush_rx_fifo(&spi_master);
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
int32_t _AD717X_SPI_Read(uint8_t* buf, uint32_t buflength)
{
	if(spi_master_write_read_stream(&spi_master, (char*)buf, (char*)buf, buflength)!= HAL_OK)
		return -5;
	return 0;
}
