#include "adtpi.h"
#include "semphr.h"
#include "ad717x.h"
#include <math.h>
#include "ad717x_communication.h"


#define AD7176_2_INIT
#include "ad7176_2_regs.h"

struct ad717x_device ad7176_2;
#define ARRAY_SIZE(a) (sizeof(a) / sizeof((a)[0]))
ad717x_st_reg ad7176_2_regs_active[ARRAY_SIZE(ad7176_2_regs)];

xSemaphoreHandle lock;

//Local functions
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
int set_ad7176_gpio(struct ad717x_device *device, uint8_t set_clear)
{
	int ret;
	ad717x_st_reg *ad7176_2_GPIO;
	
	ad7176_2_GPIO = AD717X_GetReg(device, AD717X_GPIOCON_REG);
	
	if(set_clear > 0)
		ad7176_2_GPIO->value = ad7176_2_GPIO->value|AD717X_GPIOCON_REG_DATA1;
	else
		ad7176_2_GPIO->value = ad7176_2_GPIO->value&(~AD717X_GPIOCON_REG_DATA1);

	ret = AD717X_WriteRegister(device, ad7176_2_GPIO->addr);
	return ret;
}
//////////////////////////////////////////////////////////////////////////////////
int set_ad7176_channel(struct ad717x_device *device, uint8_t channel)
{
	int ret;
	ad717x_st_reg *ad7176_2_CH;

	for(int i = 0; i < 4; i ++) {
		ad7176_2_CH = AD717X_GetReg(device, AD717X_CHMAP0_REG + i);	// ch0
		if(channel == i)
			ad7176_2_CH->value = ad7176_2_CH->value | AD717X_CHMAP_REG_CH_EN;  // enable
		else
			ad7176_2_CH->value = ad7176_2_CH->value & (~AD717X_CHMAP_REG_CH_EN); // disable
		ret = AD717X_WriteRegister(device, ad7176_2_CH->addr);
		if(ret < 0)
			return ret;
	}
	return ret;
}

//////////////////////////////////////////////////////////////////////////////////
void claculate_stats(stats_type * result_statistics, double* input_buffer, int size)
{
	int i;
	     //result average
		result_statistics->avg = 0;
		for (i = 0; i < size; ++i)
			result_statistics->avg += input_buffer[i];
		result_statistics->avg /=  size;
#if 1
		//result standard dev
		result_statistics->std = 0;
		for (i = 0; i < size; ++i)
			result_statistics->std += (input_buffer[i] - result_statistics->avg)*(input_buffer[i] - result_statistics->avg);
		result_statistics->std = sqrt(result_statistics->std / size);
	
		result_statistics->enob = M_BIT - log10(result_statistics->std)/LOG10_2;//http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.555.2763&rep=rep1&type=pdf
   
		//result_statistics.avg = abs(result_statistics.avg - COUNTS_MAX);//this in case if detector is inverting
#endif
}
//////////////////////////////////////////////////////////////////////////////////
double convert_counts(unsigned int adc_counts)
{
	double delta_Vin, Vin;
		
		//table interpolation will be better
		
		//see header file for constants
		delta_Vin = (2*(double)adc_counts/COUNTS_MAX - 1)*V_REF;
	    Vin = V_OFFS + delta_Vin/INPUT_GAIN;
		
		return Vin;
}
//////////////////////////////////////////////////////////////////////////////////
int get_adc_data(struct ad717x_device *device, uint8_t channel, double* input_buffer, int size)
{
	unsigned int data_reg, adc_result;

	int i, ret = 0;
	
	set_ad7176_channel(device, channel);
	
	for(i = 0; i < size; i++) {

		if(start_ad717x_conversion(i) != 0) {
				printf("ADC conversion timeout\n");
				break;
		}

		ret = AD717X_ReadData(device, (int32_t*)&data_reg);			
		if(ret < 0)
			break;
//		unsigned int data_status = data_reg & 0xff;	// adc status reg not further used/returned yet... maybe in future. see datasheet for status reg bit meanings
		adc_result = (data_reg >> 8) & 0xffffff;
		
		#ifdef CONVERT_COUNTS
			input_buffer[i] = convert_counts(adc_result);
		#else
			input_buffer[i] = (double)adc_result;
		#endif
	}
	
	return ret;
}
//////////////////////////////////////////////////////////////////////////////////
int init_ad7176(void)
{
	int ret = 0, i;
	ad717x_st_reg *ad7176_2_ID;
	ad717x_st_reg *ad7176_2_ADC_MODE;
	
	//need to do these things for re-initialization to work correctly
	//-->
	for(i = 0; i < ARRAY_SIZE(ad7176_2_regs); i++)
		ad7176_2_regs_active[i] = ad7176_2_regs[i];
	
	ad7176_2.slave_select_id = 0;
	ad7176_2.regs = NULL;
	ad7176_2.num_regs = 0;
	ad7176_2.useCRC = AD717X_DISABLE;
	//<--
	
	ret = (int)AD717X_Setup(&ad7176_2, AD7176_2_SLAVE_ID, ad7176_2_regs_active, ARRAY_SIZE(ad7176_2_regs_active));	
	if(ret < 0)
	{
		printf("AD717X_Setup failed. error code: %d\n", ret);
		return ret;
	}
	
	//enable 2.5V reference for diff drivers common mode voltage
	ad7176_2_ADC_MODE = AD717X_GetReg(&ad7176_2, AD717X_ADCMODE_REG);
	ad7176_2_ADC_MODE->value = ad7176_2_ADC_MODE->value|AD717X_ADCMODE_REG_REF_EN;
	AD717X_WriteRegister(&ad7176_2, ad7176_2_ADC_MODE->addr);
	
	//reading ADC status register value. Should be 0x0c94 for AD7172-2
	AD717X_ReadRegister(&ad7176_2, AD717X_ID_REG);

	ad7176_2_ID = AD717X_GetReg(&ad7176_2, AD717X_ID_REG);
	printf("ADC ID: %#04x <--", (unsigned int)ad7176_2_ID->value);
	if(ad7176_2_ID->value == 0x0c94)
		printf("OK (AD7172-2)\n");
	else
		printf("Wrong!\n");
	
	unsigned int data_reg;
	ret = AD717X_ReadData(&ad7176_2, (int32_t*)&data_reg);//dummy read
	if(ret < 0)
		printf("dummy AD717X_ReadData failed. error code: %d\n", ret);
	
	return ret;
}
//////////////////////////////////////////////////////////////////////////////////
int init_periph(void)
{
	int ret = init_drv_ad717x();
	if(ret < 0)
	{
		printf("DrvAd717x initialization failed. error code: %d\n", ret);
		return ret;
	}
			
	ret = init_ad7176();
	if (ret < 0)
	{
	   printf("ad7176 initialisation failed\n");
	   return ret;
	}
	
	printf("Initialisation successful\n");
	return ret;
}
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
int global_crc_error_counter = 0;
	
int handle_ret(int ret)//very imortant to have. Somethimes comunications can crash (for example in case of psu impulses etc)
{
	if(ret < 0)
	{
		if(ret ==  COMM_ERR)
		{
			printf("CRC_ERR\n");
			global_crc_error_counter++;
			
			if(global_crc_error_counter >= 10) //if N crc errors in row...
			{
				printf("CRC errors too often. Initiating again...\n");
				global_crc_error_counter = 0;
				deinit_drv_ad717x();
				return init_periph();
			}
		}			
		else if(ret ==  INVALID_VAL)
			printf("INVALID_VAL\n");
		else if(ret ==  COMM_ERR)
			printf("TIMEOUT\n");
		else
			printf("error code: %d\n", ret);		
	}

	return ret;
}
//////////////////////////////////////////////////////////////////////////////////
double adc_buffer[AVG_COUNT];
//////////////////////////////////////////////////////////////////////////////////

//Start of MAIN()
//////////////////////////////////////////////////////////////////////////////////
void ad717x_main(int argc, char *argv[])
{	
	stats_type result_statistics;
	int i, channel = 0, count = 4;
	if (argc > 1) {
			channel = atoi(argv[1]);
			channel &= 0x03;
	}
	if (argc > 2) {
		count = atoi(argv[1]);
		if(count < 1) count = 1;
	}
	vSemaphoreCreateBinary(lock);
	//ADC part.......................................................................
	if(init_periph() < 0)
	{
		printf("Init failed\n");
        goto terminate;
	}
		
	vTaskDelay(500);
		
    set_ad7176_gpio(&ad7176_2, 1);	//	turn on gpio led

    for(i = 0; i < count; i++) {
    	int x = (argc == 1)? i : channel;
    	int ret = get_adc_data(&ad7176_2, x, adc_buffer, AVG_COUNT);
    	handle_ret(ret);
    	if(ret >= 0) {
        	claculate_stats(&result_statistics, adc_buffer, AVG_COUNT);
        	c_printf("\nCH%d avg: %lf\n", x, result_statistics.avg);
    		c_printf("CH%d std: %lf\n", x, result_statistics.std);
    		c_printf("CH%d ENOB: %lf\n", x, result_statistics.enob);
    	}
    }

	set_ad7176_gpio(&ad7176_2, 0);	//	turn off gpio led
#if 0
	printf(".............................\n");
	//SERVER part..................................................................
	int socket_desc , client_sock , c;
    struct sockaddr_in server , client;
	
    //Create socket
    socket_desc = socket(AF_INET , SOCK_STREAM , 0);
    if (socket_desc == -1)
    {
        printf("Could not create socket\n");
        goto terminate;
    }
    printf("Socket created\n");
     
    //Prepare the sockaddr_in structure
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(LISTEN_PORT);
     
    //Bind
    if( bind(socket_desc,(struct sockaddr *)&server , sizeof(server)) < 0)
    {
        //print the error message
    	printf("bind failed. Error\n");
        goto terminate;
    }
    printf("bind done\n");
     
    //Listen
    listen(socket_desc , 3);//3 slots

    //Accept and incoming connection
    printf("Waiting for incoming connections...\n");
    c = sizeof(struct sockaddr_in);
	pthread_t thread_id;
	
    while( (client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t*)&c)) ) //<--blocking call here
    {
		printf("Connection accepted\n");
		
		if(inet_ntop(AF_INET,&client.sin_addr.s_addr,clntName,sizeof(clntName))!=NULL)
		   printf("client IP address and assigned port: %s%c%d\n", clntName,'/',ntohs(client.sin_port));
		else 
		   printf("Unable to get client address\n");

        if( pthread_create( &thread_id , NULL ,  connection_handler , (void*) &client_sock) < 0)
        {
        	printf("could not create thread\n");
            goto terminate;
        }
         
        //Now join the thread , so that we dont terminate before the thread
        //pthread_join( thread_id , NULL);
		pthread_detach(thread_id); /* don't track it */
		printf("Handler assigned\n");
    }
     
    if (client_sock < 0)
    {
    	printf("accept failed\n");
    }
	shutdown(socket_desc, SHUT_RDWR);
#endif

terminate:
	deinit_drv_ad717x();
	vSemaphoreDelete(lock);
//	return 0;
}//END MAIN()

#if 0
//////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
/*
 * This will handle connection for each client
 * */
void *connection_handler(void *socket_desc)
{
    //Get the socket descriptor
    int sock = *(int*)socket_desc;
    int read_size;
    char *message , client_message[CLIENT_MSG_LENGTH];
     stats_type stats_ch0, stats_ch1;
	
	char double_string_buf[15];
	
	unsigned int timeout;
	int ret;
    //Send some messages to the client
    //message = "\nAD7176 ready. Send tpm to get tp reading\n\n";
    //write(sock , message , strlen(message));
	
    //Receive a message from client
    while( (read_size = recv(sock , client_message , CLIENT_MSG_LENGTH , 0)) > 0 )
    {
        //end of string marker
		client_message[read_size] = '\0';
		
		//Send the message back to client
		if(strcmp(client_message, "tpm") == 0)
		{			
			xSemaphoreTake(lock, portMAX_DELAY);//prevent other threads executing following code until unlocked
				
				set_ad7176_gpio(&ad7176_2, 1);//turn on gpio led <-no spi reads in this function
				
				
				ret = get_adc_data(&ad7176_2, CH0, adc_buffer_ptr, AVG_COUNT);					
				handle_ret(ret);
				
				if(ret >= 0) //if ret was <0, send last correct value	
				{
					stats_ch0 = claculate_stats(adc_buffer_ptr, AVG_COUNT);
					
					if(global_crc_error_counter > 0)
					printf("at ch0: crc error count: %d. clearing\n", global_crc_error_counter);
				
					global_crc_error_counter = 0;
				}								
								
				sprintf(double_string_buf, "%u", (unsigned int)stats_ch0.avg);
				strcpy(client_message, double_string_buf);
				strcat(client_message, " ");
				sprintf(double_string_buf, "%u", (unsigned int)stats_ch0.std);
				strcat(client_message, double_string_buf);
				
				strcat(client_message, " ");
				
				ret = get_adc_data(&ad7176_2, CH1, adc_buffer_ptr, AVG_COUNT);
				handle_ret(ret);
				
				if(ret >= 0)
				{					
					stats_ch1 = claculate_stats(adc_buffer_ptr, AVG_COUNT);
					
					if(global_crc_error_counter > 0)
					printf("at ch1: crc error count: %d. clearing\n", global_crc_error_counter);
				
					global_crc_error_counter = 0;
				}
				
				sprintf(double_string_buf, "%u", (unsigned int)stats_ch1.avg);
				strcat(client_message, double_string_buf);
				strcat(client_message, " ");
				sprintf(double_string_buf, "%u", (unsigned int)stats_ch1.std);
				strcat(client_message, double_string_buf);
				
				set_ad7176_gpio(&ad7176_2, 0);//turn off gpio led	
				
				xSemaphoreGive(lock);
			
			sent_response:
			write(sock , client_message , strlen(client_message) + 1);
			//clear the message buffer
			memset(client_message, 0, CLIENT_MSG_LENGTH);
		}
    }
     
    if(read_size == 0)
    {
    	printf("Client disconnected\n");
    }
    else if(read_size == -1)
    {
    	printf("recv failed\n");
    }
         
    return 0;
} 
#endif

MON_RAM_TAB_SECTION COMMAND_TABLE console_commands_ad717x[] = {
		{"AT71", 0, ad717x_main, ": Test AD7176-2"}
};
