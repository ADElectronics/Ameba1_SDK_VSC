LOCAL void fATUVC(int argc, char *argv[]) {
#if 1
	 ConfigDebugErr  = -1;
	 ConfigDebugInfo = ~(_DBG_SPI_FLASH_|_DBG_TCM_HEAP_);
	 ConfigDebugWarn = -1;
	 CfgSysDebugErr = -1;
	 CfgSysDebugInfo = -1;
	 CfgSysDebugWarn = -1;
#endif
	if(argc > 1) {
		int i = atoi(argv[1]);
		_usb_init();
		if(wait_usb_ready() < 0) printf("\r\nFail to init usb driver!\n");
		else {
			printf("UVC stream init...\n");
			if(uvc_stream_init() < 0) printf("Fail!\n");
			else {
				printf("Set video format information...\n");
                uvc_ctx.fmt_type = V4L2_PIX_FMT_YUYV; // UVC_FORMAT_H264;
                uvc_ctx.width = 320; // 640; // 1280;
                uvc_ctx.height =200; // 480; // 720;
                uvc_ctx.frame_rate = 30;
                uvc_ctx.compression_ratio = 0;
				switch(i) {
				case 1:
	                uvc_ctx.width = 160;
	                uvc_ctx.height = 120;
	                break;
				case 2:
	                uvc_ctx.width = 176;
	                uvc_ctx.height = 144;
	                break;
				case 4:
	                uvc_ctx.width = 352;
	                uvc_ctx.height = 288;
	                break;
				case 5:
	                uvc_ctx.width = 640;
	                uvc_ctx.height = 480;
	                break;
				default: // 3
	                uvc_ctx.width = 320;
	                uvc_ctx.height = 240;
	                break;
				}
//	                uvc_ctx.fmt_type = UVC_FORMAT_MJPEG; // UVC_FORMAT_H264;

//	    			if(uvc_set_param(uvc_ctx.fmt_type, &uvc_ctx.width, &uvc_ctx.height, &uvc_ctx.frame_rate, &uvc_ctx.compression_ratio) < 0) {
    			if(v4l_set_param(uvc_ctx.fmt_type, &uvc_ctx.width, &uvc_ctx.height, &uvc_ctx.frame_rate, &uvc_ctx.compression_ratio) < 0) {
    				printf("Fail to init uvc stream!\n");
    			} else {
    				printf("\r\nStart camera...\n");
    				if(uvc_stream_on() < 0) printf("Fail start stream!\n");
    				else {
//	    					for(int i = 0; i < 7; i++ )
    					{
   				            int ret = uvc_dqbuf(&buf);
   				            if(buf.index < 0) {
   				            	printf("\r\nbuf.index = %d\r\n", buf.index);

   				            } else if( (uvc_buf_check(&buf) < 0) || (ret < 0) ) {
   				            	printf("\r\nBuffer error!\r\n");
   				            } else {
   				            	uvc_is_stream_off();
	   							printf("\r\nFrame at %p[%d]:\r\n", buf.data, buf.len);
	   							dump_bytes((u32)buf.data, 32);
	   							printf("\r\nEnd Frame:\r\n");
	   							dump_bytes((u32)buf.data + buf.len - 32, 32);
   				            }
    					}
    				}
                }
			}
		}
	}
	if(uvc_is_stream_on()) {
		printf("\r\nuvc_stream_off.\n");
		uvc_stream_off();
	}
	printf("\r\nuvc_stream_free.\n");
	uvc_stream_free();
	printf("\r\nUSB deinit.\n");
	_usb_deinit();
}