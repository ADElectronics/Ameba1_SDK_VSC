/*
 * sleep_tst.c
 *
 *      Author: pvvx
 */

#include "rtl8195a.h"
#include "FreeRTOS.h"
#include "freertos_pmu.h"
//#include "hal_soc_ps_monitor.h"
#include "wifi_api.h"
#include "gpio_api.h"
#include "rtl8195a/rtl_libc.h"

extern _LONG_CALL_ VOID HalCpuClkConfig(unsigned char CpuType);
extern _LONG_CALL_ VOID VectorTableInitRtl8195A(u32 StackP);
extern _LONG_CALL_ VOID HalInitPlatformLogUartV02(VOID);
extern _LONG_CALL_ VOID HalInitPlatformTimerV02(VOID);
extern int rtl_printf(const char *fmt, ...);


void new_start(void)
{
	HalPinCtrlRtl8195A(JTAG, 0, 1);
	__asm__ __volatile__ ("cpsid f\n");
	HalCpuClkConfig(0); // 0 - 166666666 Hz, 1 - 83333333 Hz, 2 - 41666666 Hz, 3 - 20833333 Hz, 4 - 10416666 Hz, 5 - 4000000 Hz
	ConfigDebugErr = -1;
	VectorTableInitRtl8195A((u32) 0x1FFFFFFC);
	HalInitPlatformLogUartV02();
	HalInitPlatformTimerV02();
	__asm__ __volatile__ ("cpsie f\n");
//	printf("\r\nStart Init code: %d\r\n", ini);
	printf("SOC_FUNC_EN: 0x%08x\r\n", HAL_PERI_ON_READ32(REG_SOC_FUNC_EN));
	printf("SOC_FUNC_EN: 0x%08x\r\n", HAL_PERI_ON_READ32(REG_SOC_FUNC_EN));
    while(1) {
    }
}


extern u8 __ram_start_table_start__[];
void preslpset(void)
{
	HAL_PERI_ON_WRITE32(REG_SOC_FUNC_EN, HAL_PERI_ON_READ32(REG_SOC_FUNC_EN) | 0x20000000);
//	HAL_PERI_ON_WRITE32(REG_SOC_FUNC_EN, HAL_PERI_ON_READ32(REG_SOC_FUNC_EN) | 0x4000000);
#if 1
	PRAM_FUNCTION_START_TABLE pRamStartFun = (PRAM_FUNCTION_START_TABLE) __ram_start_table_start__;
//	pRamStartFun->RamStartFun = new_start;
	pRamStartFun->RamWakeupFun = new_start;
//	pRamStartFun->RamWakeupFun = WakeFromSLPPG;
//	pRamStartFun->RamPatchFun0 = new_start;
//	pRamStartFun->RamPatchFun1 = new_start;
//	pRamStartFun->RamPatchFun2 = new_start;
#else
	InitSoCPM();
#endif
}

/*
 *
 */
extern void BackupCPUClk(void);

LOCAL void fATDSA(int argc, char *argv[]) {
	uint32 level = 0;
    BackupCPUClk(); // else Error clk! после перезагрузки UART Baud x2 на RTL8710AF и CLK 166MHz!
	if (argc > 1) level = atoi(argv[1]) != 0;
	standby_wakeup_event_add(STANDBY_WAKEUP_BY_PA5, 0, level);
	deepstandby_ex(); // 0 mA
}

extern void HalInitLogUart(void);
extern void HalDeinitLogUart(void);

/* RTL8195AM (166MHz):
 * atdss=5000,1,1,1 // 9.31 mA
 * atdss=5000,1,1,0 // 10.85 mA
 * atdss=5000,1,0,x // 4.25 mA
 */
LOCAL void fATDSS(int argc, char *argv[]) {
	uint32 sleep_ms = 5000; //max 8355 ms!
	uint32 wakeup_event = SLP_STIMER; // 1.15 mA (83MHz), 1.53 (166MHz). ( = wakelock)
	uint32 clk_source_en = 0;
	uint32 sdr_en = 0;
	if (argc > 1) {
		sleep_ms = atoi(argv[1]);
		if (argc > 2) {
			wakeup_event = atoi(argv[2]);
			if (argc > 3) {
				clk_source_en = atoi(argv[3]) != 0;
				if (argc > 4) {
					sdr_en = atoi(argv[4]) != 0;
				}
			}
		}
	}
	// turn off log uart, < 1 mA
    HalDeinitLogUart(); // sys_log_uart_off();
	sleep_ex_selective(wakeup_event, sleep_ms, clk_source_en, sdr_en);
	HalInitLogUart(); // sys_log_uart_on();
}


extern VOID SleepPG(u8  Option, u32 SDuration);
extern VOID SleepPwrGatted(u32 SDuration);

LOCAL void fATDSP(int argc, char *argv[]) {
	uint32 sleep_ms = 5000; // Предел 8355 ms!
	if (argc > 1)
		sleep_ms = atoi(argv[1]);
	preslpset();
	printf("Sleep Timer %u tik\n", sleep_ms);
	wifi_run(0);
//	HalLogUartWaitTxFifoEmpty();
//	SleepPwrGatted(sleep_ms); // перезагрука через RamWakeupFun sleep_tik
//	SoCPWRIdleTaskHandle(); //	CPURegBackUp();
	SleepPG(SLP_STIMER, sleep_ms); // перезагрука через RamWakeupFun (2.5mA / 166MHz, 2.3 / 83 Mhz)
//	SleepClkGatted(sleep_tik); // не перезагружает.
	//	DSleep(sleep_tik);
	//	DStandby(sleep_tik);
//	SleepCG(SLP_STIMER, sleep_ms, 0, 0);
}

extern void DSleep_Timer(u32 SDuration);

#if 0
LOCAL void fATDST(int argc, char *argv[]) {
	uint32 sleep_ms = 5000; // Предел 8355 ms!
	if (argc > 1)
		sleep_ms = atoi(argv[1]);
	preslpset();
	printf("Sleep Timer %u tik\n", sleep_ms);
	HalLogUartWaitTxFifoEmpty();
	DSleep_Timer(sleep_ms);
}

extern void DSleep_GPIO(void);

LOCAL void fATDSG(int argc, char *argv[]) {
	(void)argc;(void)argv;
	preslpset();
	printf("Sleep GPIO\n");
	HalLogUartWaitTxFifoEmpty();
	DSleep_GPIO();
}

#endif

//------------------------------------------------------------------------------
// Deep sleep PB_1
//------------------------------------------------------------------------------
LOCAL void fATDSB(int argc, char *argv[]) {
	uint32 sleep_ms = 7000;
	if (argc > 1)
		sleep_ms = atoi(argv[1]);
	printf("%u ms waiting low level on PB_1 before launching Deep-Sleep...\n",
			sleep_ms);
	// turn off log uart
	HalDeinitLogUart(); // sys_log_uart_off();

	// initialize wakeup pin
	gpio_t gpio_wake;
	gpio_init(&gpio_wake, PB_1);
	gpio_dir(&gpio_wake, PIN_INPUT);
	gpio_mode(&gpio_wake, PullDown);
	TickType_t sttime = xTaskGetTickCount();

	do {
		if (gpio_read(&gpio_wake) == 0) {
			// Enter deep sleep... Wait give rising edge at PB_1 to wakeup system.
			deepsleep_ex(DSLEEP_WAKEUP_BY_GPIO, 0); // 0 mA
		};
		vTaskDelay(1);
	} while (xTaskGetTickCount() - sttime < sleep_ms);
	HalInitLogUart(); // sys_log_uart_on();
	printf("No set pin low in deep sleep!\n");
}

MON_RAM_TAB_SECTION COMMAND_TABLE console_commands_pwrs[] = {
		{"ATDSB", 0, fATDSB, "=[wait_PB1_low(ms)]: DSleep PB_1"},
		{"ATDSA", 0, fATDSA, "=[level]: DSleep Test PA_5"},
//		{"ATDSG", 0, fATDSG, ": DSleep GPIO"},
//		{"ATDST", 0, fATDST, "=[time(ms)] DSleep Timer"},
		{"ATDSP", 0, fATDSP, "=[time(ms)]: Sleep Test"},
		{"ATDSS", 0, fATDSS, "=[time(ms)[,mode[,clk_on[,sdr_on]]]]: SleepPG"}
};

