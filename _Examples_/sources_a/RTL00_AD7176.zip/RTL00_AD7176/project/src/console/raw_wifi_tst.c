/*
 * raw_wifi_tst.c
 *  Created on: 04/04/2017
 * Set USE_P2P_WPS = 1 in project.mk !
 */
#include <platform_opts.h>
#include "FreeRTOS.h"
#include "rtl8195a.h"

#include "wifi_constants.h"
#include "wifi_structures.h"

//#include "wlan_lib.h"
#include "wifi_api.h"
#include "wifi_util.h"
#include "wifi.h"
#include "ieee80211.h"

//#include <wireless.h>
//#include <wlan_intf.h>
//#include <platform/platform_stdlib.h>
//#include <wifi/wifi_conf.h>
//#include <wifi/wifi_ind.h>
#include "freertos/wrapper.h"
#include <osdep_service.h>

#include "rtl8195a/rtl_libc.h"

#if (!defined(CONFIG_ENABLE_P2P)) || (!CONFIG_ENABLE_P2P)
//  #error "Set CONFIG_ENABLE_P2P!"
#endif

void wifi_promisc_rx(unsigned char* buf, unsigned int len, void* user_data);

#define PROMISC_FORMAT RTW_PROMISC_ENABLE_2  /**< Fetch all 802.11 packets*/

extern void wifi_enter_promisc_mode();
//------------------------------------------------------------------------------
u8 RandSK(u8 max) {
	u8 buf;
	do {
		rtw_get_random_bytes(&buf, 1);
	} while (buf>max);
	return buf;
}

char wlan0[] = "wlan0";
//------------------------------------------------------------------------------
void _enter_promisc_mode(char channel)
{
#if 1
		TickType_t tt = xTaskGetTickCount();
		wifi_enter_promisc_mode();
#else
		wifi_off();
		vTaskDelay(500);
		TickType_t tt = xTaskGetTickCount();
	    wifi_on(RTW_MODE_PROMISC);
#endif
		printf("\nWiFi enter promisc mode (%d ms)\n\n", xTaskGetTickCount() - tt);
		tt = xTaskGetTickCount();
		if(wext_set_channel(wlan0, channel) < 0) printf("\nSet chl %d error!\n\n", channel);
		else printf("\nSet chl %d (%d ms)\n\n", channel, xTaskGetTickCount() - tt);
}

//------------------------------------------------------------------------------
LOCAL void fATRT(int argc, char *argv[])
{
	// t: 40, 18:fe:34:fa:39:2d -> ff:ff:ff:ff:ff:ff, len: 42, rssi: -46
	u8 packet[128] = {
	0x40, 0x00, // Frame control
	0x00, 0x00, // duration
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff,	// DA
	0x11, 0x22, 0x33, 0x44, 0x00, 0x00, // SA
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, // BSS ID
	0x30, 0xb8, // seq-ctl
	0x00, 0x00, 0x01, 0x08, 0x8b, 0x96, 0x82, 0x84, // Timestamp
	0x0c, 0x18, 0x30, 0x60, 0x32, 0x04, 0x6c, 0x12, 0x24, 0x48, 0, 0 };

    u8 channel = 1;
    //_adapter *ad0 = rltk_wlan_info[0].dev;
    if(argc > 1) {
    	channel = atoi(argv[1]);
    }
    if((!channel) || channel > 14)  channel = 1;
    // Source MAC Address
//    packet[10] = packet[16] = RandSK(255);
//    packet[11] = packet[17] = RandSK(255);
//    packet[12] = packet[18] = RandSK(255);
//    packet[13] = packet[19] = RandSK(255);
    packet[14] = packet[20] = RandSK(255);
    packet[15] = packet[21] = RandSK(255);

    _enter_promisc_mode(channel);
	rtw_msleep_os(100);
    //while(1) {
        for(int i=0; i < 100; i++) {
            printf("prep B %d\n",i);
            extern Rltk_wlan_t rltk_wlan_info[2];
            printf("tx,rx,en = %u,%u,%u\n", rltk_wlan_info[0].tx_busy, rltk_wlan_info[0].rx_busy, rltk_wlan_info[0].enable);
            //rtw_send_mgnt(ad0, &packet, 57, NULL);
            wext_send_mgnt(wlan0, (char *)&packet, 50, 0);
            //rtw_msleep_os(100);
            printf(".");
            vTaskDelay(20); // +WDT
        }
        //rtw_msleep_os(1000);
    //}
    printf("prep C\n");
}
//------------------------------------------------------------------------------
 void _fATRT(int argc, char *argv[])
{
	u8 alfa[65] = "1234567890qwertyuiopasdfghjklzxcvbnm QWERTYUIOPASDFGHJKLZXCVBNM_.";
    u8 packet[128] = {
    	/*0*/	0x80, 0x00, // Frame control
		/*2*/   0x00, 0x00, // duration
        /*4*/   0xff, 0xff, 0xff, 0xff, 0xff, 0xff, // DA
        /*10*/  0x01, 0x02, 0x03, 0x04, 0x05, 0x06, // SA
        /*16*/  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, // BSS ID
        /*22*/  0xc0, 0x6c, // seq-ctl
		/* Variable */
        	/*24*/  0x83, 0x51, 0xf7, 0x8f, 0x0f, 0x00, 0x00, 0x00, // Timestamp
			/*32*/  0x64, 0x00, // Beacon interval
			/*34*/  0x01, 0x04, // Capability Info
			/* SSID */ // none = Variable
			/* Optional */
			/*36*/  0x00, 0x06, 0x72, 0x72, 0x72, 0x72, 0x72, 0x72,
					0x01, 0x08, 0x82, 0x84,
					0x8b, 0x96, 0x24, 0x30, 0x48, 0x6c, 0x03, 0x01,
			/*56*/  0x04};
    u8 channel = 1;
    //_adapter *ad0 = rltk_wlan_info[0].dev;
    if(argc > 1) {
    	channel = atoi(argv[1]);
    }
    if((!channel) || channel > 14)  channel = 1;
    // Source MAC Address
    packet[10] = packet[16] = RandSK(255);
    packet[11] = packet[17] = RandSK(255);
    packet[12] = packet[18] = RandSK(255);
    packet[13] = packet[19] = RandSK(255);
    packet[14] = packet[20] = RandSK(255);
    packet[15] = packet[21] = RandSK(255);
    // Randomize SSID (Fixed size 6. Lazy right?)
//    packet[38] = alfa[RandSK(65)];
//    packet[39] = alfa[RandSK(65)];
    packet[40] = alfa[RandSK(65)];
    packet[41] = alfa[RandSK(65)];
    packet[42] = alfa[RandSK(65)];
    packet[43] = alfa[RandSK(65)];

    packet[56] = channel;

    _enter_promisc_mode(channel);
	rtw_msleep_os(100);
    //while(1) {
        for(int i=0; i < 1000; i++) {
            printf("prep B %d\n",i);
            extern Rltk_wlan_t rltk_wlan_info[2];
            printf("tx,rx,en = %u,%u,%u\n", rltk_wlan_info[0].tx_busy, rltk_wlan_info[0].rx_busy, rltk_wlan_info[0].enable);
            //rtw_send_mgnt(ad0, &packet, 57, NULL);
            wext_send_mgnt(wlan0, (char *)&packet, 57, 0);
            //rtw_msleep_os(100);
            printf(".");
            vTaskDelay(20); // +WDT
        }
        //rtw_msleep_os(1000);
    //}
    printf("prep C\n");
}

//------------------------------------------------------------------------------
extern void dump_bytes(uint32 addr, int size);
char promisc_run = 0;
// callback for promisc packets, like rtk_start_parse_packet in SC, wf, 1021
void wifi_promisc_rx(unsigned char* buf, unsigned int len, void* user_data)
{
	unsigned short fc = ((ieee80211_frame_info_t *)user_data)->i_fc;
//	if (fc == RTW_IEEE80211_STYPE_BEACON) return;
	unsigned char * da = ((ieee80211_frame_info_t *)user_data)->i_addr1;
	unsigned char * sa = ((ieee80211_frame_info_t *)user_data)->i_addr2;
	signed char rssi = ((ieee80211_frame_info_t *)user_data)->rssi;
	unsigned char str_da[20];
	unsigned char str_sa[20];
	if (promisc_run) {
		mactostr(str_da, da, true);
		mactostr(str_sa, sa, true);
		printf("%04x %s->%s rssi: %d\t[%d]\n", fc, str_sa, str_da, rssi, len);
	}
}

//------------------------------------------------------------------------------
#if 0
#define filter_num 1	// id (номер) фильтра
#define	mask_mode RTW_POSITIVE_MATCHING
#define mask1_val RTW_IEEE80211_STYPE_PROBE_REQ // Probe request
#define mask1_off 0		// смещение в буфере для наложения маски
#define mask1_len 2		// длина маски в байтах
u8 mask1[mask1_len] = { 0xFF, 0xFF }; // маска
u8 pattern1[mask1_len] = { mask1_val & 0xFF, (mask1_val >> 8) & 0xFF };
rtw_packet_filter_pattern_t packet_filter[filter_num] = {
 {  .offset = mask1_off, // применить маску для смещения 0 в буфере пакета
	.mask = mask1, // сама маска
	.mask_size = mask1_len, // длина маски
	.pattern = pattern1 } // чему должно быть равно
};
#elif 0
#define filter_num 1	// id (номер) фильтра
#define	mask_mode RTW_NEGATIVE_MATCHING
#define mask1_val RTW_IEEE80211_STYPE_BEACON // Beacon
#define mask1_off 0		// смещение в буфере для наложения маски
#define mask1_len 2		// длина маски в байтах
u8 mask1[mask1_len] = { 0xFF, 0xFF }; // маска
u8 pattern1[mask1_len] = { mask1_val & 0xFF, (mask1_val >> 8) & 0xFF };
rtw_packet_filter_pattern_t packet_filter[filter_num] = {
 {  .offset = mask1_off, // применить маску для смещения 0 в буфере пакета
	.mask = mask1, // сама маска
	.mask_size = mask1_len, // длина маски
	.pattern = pattern1 } // чему должно быть равно
};
#elif 1
#define filter_num	 2  // кол-во фильтров
#define	mask_mode RTW_POSITIVE_MATCHING
#define mask_len 6		// длина маски в байтах
u8 mask[mask_len] = { 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF }; // маска
u8 pattern[mask_len] = { 0x18, 0xfe, 0x34, 0xfa, 0x39, 0x2d };
rtw_packet_filter_pattern_t packet_filter[filter_num] = {
 {  .offset = 4, // применить маску для смещения 0 в буфере пакета
	.mask = mask, // сама маска
	.mask_size = mask_len, // длина маски
	.pattern = pattern }, // чему должно быть равно
 {  .offset = 4+6, // применить маску для смещения 0 в буфере пакета
	.mask = mask, // сама маска
	.mask_size = mask_len, // длина маски
	.pattern = pattern } // чему должно быть равно
};

#endif

//------------------------------------------------------------------------------
LOCAL void fATRS(int argc, char *argv[])
{
    //_adapter *ad0 = rltk_wlan_info[0].dev;
	u8 channel = 1;
    if(argc > 1) {
    	channel = atoi(argv[1]);
        if((!channel) || channel > 14)  channel = 1;
        if (promisc_run) {
        	if(wext_set_channel(wlan0, channel) < 0) printf("\nSet chl %d error!\n\n", channel);
        	else printf("\nPromisc mode set chl %d\n\n", channel);
        	return;
        }
    }
    if(promisc_run)  {
    	promisc_run = 0;
		wifi_set_promisc(RTW_PROMISC_DISABLE, wifi_promisc_rx, 1);
#ifdef filter_num
		int i;
		for(i = filter_num; i > 0; i-- )
			wifi_disable_packet_filter(i);
		for(i = filter_num; i > 0; i-- )
			wifi_remove_packet_filter(i);
#endif
		printf("\nWiFi promisc mode disable\n\n");
	} else {
	    _enter_promisc_mode(channel);
		/* enable all 802.11 packets*/
		wifi_set_promisc(RTW_PROMISC_ENABLE_2, wifi_promisc_rx, 1);
#ifdef filter_num
		wifi_init_packet_filter();
		int i;
		for(i = 1; i <= filter_num; i++ )
			wifi_add_packet_filter(i, &packet_filter[i-1], mask_mode);
		for(i = 1; i <= filter_num; i++ )
			wifi_enable_packet_filter(i);
#endif
    	promisc_run = 1;
	}
}

//------------------------------------------------------------------------------
MON_RAM_TAB_SECTION COMMAND_TABLE console_commands_rwt[] = {
		{"ATRT", 0, fATRT, "[chl]: Raw WiFi Test"},
		{"ATRS", 0, fATRS, "[chl]: Sniffer WiFi Test"}
};


