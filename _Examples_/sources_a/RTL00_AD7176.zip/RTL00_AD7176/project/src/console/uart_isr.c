/*
 *  Reverse: uart_isr.c
 *
 *  Created on: 09/06/2017.
 *      Author: pvvx
 */


void _UartIrqHandle(void *data){
	PHAL_RUART_ADAPTER pru = (PHAL_RUART_ADAPTER) data;
	u32 puart = UART0_REG_BASE + (pru->UartIndex*RUART_REG_OFF);
	int i = 5;
	do {
		u8 val = HAL_READ8(puart, RUART_INT_ID_REG_OFF);
		if(val & RUART_IIR_INT_PEND) break;
		switch((val>>1) & 7) {
			case 6: // character timeout
			case 2: // received data available
				if((pru->State & 1) == HAL_UART_STATE_BUSY_RX) {
					while(pru->RxCount) {
						if(!(HAL_READ32(puart, RUART_LINE_STATUS_REG_OFF) & RUART_LINE_STATUS_REG_DR))
							goto switch_end;
						*pru->pRxBuf = HAL_READ32(puart, RUART_REV_BUF_REG_OFF);
						pru->RxCount--;
						pru->pRxBuf++;
					}
					if(!(pru->RxDRCallback)) {
						pru->Interrupts &= ~(RU_IER_ERBFI|RU_IER_ELSI);
						HalRuartSetIMRRtl8195a(pru);
					}
					pru->Status |= (HAL_READ32(puart, RUART_LINE_STATUS_REG_OFF) & 0x9E);
					if(pru->State == HAL_UART_STATE_BUSY_RX)
						pru->State = HAL_UART_STATE_READY;
					else
						pru->State = HAL_UART_STATE_BUSY_TX;
					if(pru->RxCompCallback)
						pru->RxCompCallback(pru->RxCompCbPara);
				} else {
					while(HAL_READ32(puart, RUART_LINE_STATUS_REG_OFF) & RUART_LINE_STATUS_REG_DR) {
						if(pru->RxDRCallback)
							pru->RxDRCallback(pru->RxDRCbPara);
					}
				}
				break;
	        case 1: // THR empty
	        	if((pru->State & (~2)) == HAL_UART_STATE_BUSY_TX) {
	        		while(pru->TxCount) {
	        			if(!(HAL_READ32(puart, RUART_LINE_STATUS_REG_OFF) & RUART_LINE_STATUS_REG_THRE))
	        				goto switch_end;
        				HAL_WRITE32(puart, RUART_TRAN_HOLD_REG_OFF, (u8)*pru->pTxBuf);
        				pru->pTxBuf++;
        				pru->TxCount--;
	        		}
        			// Disable Transmit Holding Register Empty Interrupt
					pru->Interrupts &= ~RU_IER_ETBEI;
					HalRuartSetIMRRtl8195a(pru);
					if(pru->State == HAL_UART_STATE_BUSY_TX)
						pru->State = HAL_UART_STATE_READY;
					else
						pru->State = HAL_UART_STATE_BUSY_RX;
					if(pru->TxCompCallback)
						pru->TxCompCallback(pru->TxCompCallback);
	        	} else {
	        		if(pru->TxTDCallback)
	        			pru->TxTDCallback(pru->TxTDCbPara);
	        	}
	        	break;
	        case 3: // receiver line status / busy detect?
	        	pru->Status |= (HAL_READ32(puart, RUART_LINE_STATUS_REG_OFF) & 0x9E);
	            break;
	        case 0:  // modem status?
	        	pru->ModemStatus = HAL_READ32(puart, RUART_MODEM_STATUS_REG_OFF);
	        	if(pru->ModemStatusInd)
	        		pru->ModemStatusInd(pru);
	            break;
		}
switch_end:
		i--;
	} while(i);
}
