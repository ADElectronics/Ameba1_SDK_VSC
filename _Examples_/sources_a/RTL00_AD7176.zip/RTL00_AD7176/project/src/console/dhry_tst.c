/*
 * adc_tst.c
 *
 *  Created on: 04/04/2017.
 *      Author: pvvx
 */

#include <platform_opts.h>
#include "rtl8195a.h"
#include "FreeRTOS.h"
#include "rtl8195a/rtl_libc.h"
#include "dhry.h"

#define delay(ms) vTaskDelay(ms) 
#define millis xTaskGetTickCount

extern int c_printf(const char *fmt, ...);

//------------------------------------------------------------------------------

void fATDRY(int argc, char *argv[]) {
	(void)argc; (void)argv;
#if 1
	// https://www.eevblog.com/forum/microcontrollers/dhrystone-2-1-on-mcus/
	int Number_Of_Runs = 1000000;
	uint32_t User_Time = dhry_main(Number_Of_Runs);
	float CpuClkMhz = (float) HalGetCpuClk() / 1000000.0;

	c_printf ("RunTime %u ms, CPU CLK %f MHz, Run Cycles %u\n", User_Time, CpuClkMhz, Number_Of_Runs);

	  if (User_Time < Too_Small_Time) {
	    c_printf ("Measured time too small to obtain meaningful results\n");
	    c_printf ("Please increase number of runs\n");
	    c_printf ("\n");
	  } else {
		  float Microseconds = (float) User_Time * 1000.0
	                        / (float) Number_Of_Runs;
		  float Dhrystones_Per_Second = (float) Number_Of_Runs
	                        / (float) User_Time * 1000.0;
		  c_printf ("Microseconds for one run through Dhrystone: ");
		  c_printf ("%f \n", Microseconds);
		  c_printf ("Dhrystones per Second:                      ");
		  c_printf ("%f \n", Dhrystones_Per_Second);
		  c_printf ("Dhrystones per MHz:                         ");
		  c_printf ("%f \n", Dhrystones_Per_Second / CpuClkMhz);
		  c_printf ("%f DMIPS, %f DMIPS/MHz ?\n", Dhrystones_Per_Second / 1757.0, Dhrystones_Per_Second / 1757.0 / CpuClkMhz);
		  c_printf ("\n");
	  };

#else
    double benchtime, dps;
    unsigned int tt, t1;
    unsigned long long loops;
    dps = (double)HalGetCpuClk()/1000000.0;
	c_printf("\r\nDhrystone Benchmark Program C/1 12/01/84\r\n");
    c_printf("CLK CPU = %lf MHz.\r\n", dps);
    c_printf("Test cycles 10 sec...\r\n");
	loops = 0l;
	delay(1000);
	tt = millis();
	do {
		Proc0();
		loops += LOOPS;
		t1 = millis() - tt;
	} while (t1 < 10000);
	benchtime = (double) t1 / 1000.0;
	dps = (double) loops / benchtime;

	c_printf("Dhrystone time for %llu passes = %.3f sec\r\n", loops, benchtime);
	c_printf("This machine benchmarks at %f dhrystones/second (%f dhry/MHz)\r\n", dps, dps/(double)HalGetCpuClk());
#endif	
}

//------------------------------------------------------------------------------
MON_RAM_TAB_SECTION COMMAND_TABLE console_cmd_dhry[] = {
		{ "ATDRY", 0, fATDRY, ": Dhrystone Test" }
};


