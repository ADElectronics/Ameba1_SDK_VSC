/*
 * UART sniffer
 * Author: pvvx
 */
#include <platform_opts.h>
#include "FreeRTOS.h"
#include "rtl8195a.h"

#include "serial_api.h"
#include "serial_ex_api.h"

#include "wifi_constants.h"
#include "wifi_structures.h"
#include "wifi_api.h"
#include "wifi_util.h"
#include "wifi.h"
#include "ieee80211.h"

#include "freertos/wrapper.h"
#include <osdep_service.h>

#include "rtl8195a/rtl_libc.h"

#if (!defined(CONFIG_ENABLE_P2P)) || (!CONFIG_ENABLE_P2P)
// #error "Set CONFIG_ENABLE_P2P!"
#endif

void wifi_promisc_rx(unsigned char* buf, unsigned int len, void* user_data);

#define PROMISC_FORMAT RTW_PROMISC_ENABLE_2  /**< Fetch all 802.11 packets*/

#define UART_TX    PA_7	//PB_5
#define UART_RX    PA_6 //PB_4

char sniffer_run = 0;
volatile char sniffer_tx_busy = 0;
volatile char sniffer_send_ena = 0;
serial_t    sniffer_sobj;

void sniffer_uart_send_string_done(uint32_t id)
{
	(void)id;
    sniffer_tx_busy = 0;
}

int sniffer_send(char *ptxbuf, uint32_t len)
{
    if (sniffer_tx_busy)  return 0;
    sniffer_tx_busy = 1;
    if (serial_send_stream_dma(&sniffer_sobj, (char *)ptxbuf, len) != 0) {
        error_printf("%s Error!\n", __FUNCTION__);
        sniffer_tx_busy = 0;
    }
    return 1;
}

void sniffer_uart_irq(uint32_t id, SerialIrq event)
{
    serial_t *psniffer_sobj = (void*)id;
    if(event == RxIrq) HalSerialPutcRtl8195a(serial_getc(psniffer_sobj));
}


void sniffer_uart_init(void)
{
	serial_init(&sniffer_sobj, UART_TX, UART_RX);
	serial_baud(&sniffer_sobj, 3000000); //1509660);
	serial_format(&sniffer_sobj, 8, ParityNone, 1);

    serial_irq_handler(&sniffer_sobj, sniffer_uart_irq, (uint32_t)&sniffer_sobj);
//	serial_recv_comp_handler(&sniffer_sobj, (void*)uart_recv_string_done, (uint32_t) &sniffer_sobj);
	serial_send_comp_handler(&sniffer_sobj, (void*)sniffer_uart_send_string_done, (uint32_t) &sniffer_sobj);
}

void sniffer_uart_deinit(void)
{
	serial_free(&sniffer_sobj);
}

extern void wifi_enter_promisc_mode(void);

void enter_sniffer_mode(char channel)
{
#if 1
		wifi_enter_promisc_mode();
#else
		wifi_off();
		vTaskDelay(500);
	    wifi_on(RTW_MODE_PROMISC);
#endif
		printf("\nWiFi enter promisc mode\n");
		if(wext_set_channel(WLAN0_NAME, channel) < 0) printf("\nSet chl %d error!\n", channel);
		else printf("\nSet chl %d\n", channel);
}


//------------------------------------------------------------------------------
extern void dump_bytes(uint32 addr, int size);

unsigned char sniffer_buf[512];

// callback for promisc packets, like rtk_start_parse_packet in SC, wf, 1021
void wifi_promisc_rx(unsigned char* buf, unsigned int len, void* user_data)
{
	if (sniffer_run) {
		unsigned short fc = ((ieee80211_frame_info_t *)user_data)->i_fc;
//		if (fc == RTW_IEEE80211_STYPE_BEACON) return;
		unsigned char * da = ((ieee80211_frame_info_t *)user_data)->i_addr1;
		unsigned char * sa = ((ieee80211_frame_info_t *)user_data)->i_addr2;
		signed char rssi = ((ieee80211_frame_info_t *)user_data)->rssi;
		unsigned char str_da[20];
		unsigned char str_sa[20];
		if(sniffer_send_ena && sniffer_tx_busy == 0) {
			mactostr(str_da, da, true);
			mactostr(str_sa, sa, true);
			sniffer_send(sniffer_buf, rtl_sprintf(sniffer_buf, "%04x %s->%s rssi: %d\t[%d]\n", fc, str_sa, str_da, rssi, len));
		} else {
			mactostr(str_da, da, true);
			mactostr(str_sa, sa, true);
			printf("%04x %s->%s rssi: %d\t[%d]\n", fc, str_sa, str_da, rssi, len);
		}
	}
}

//------------------------------------------------------------------------------
#if 1
#define filter_num	 2  // кол-во фильтров
#define	mask_mode RTW_POSITIVE_MATCHING
#define mask_len 6		// длина маски в байтах
u8 mask[mask_len] = { 0xFD, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF }; // маска
u8 pattern[mask_len] = { 0x18, 0xfe, 0x34, 0xfa, 0x39, 0x2d };
rtw_packet_filter_pattern_t packet_filter[filter_num] = {
 {  .offset = 4, // применить маску для смещения 0 в буфере пакета
	.mask = mask, // сама маска
	.mask_size = mask_len, // длина маски
	.pattern = pattern }, // чему должно быть равно
 {  .offset = 4+6, // применить маску для смещения 0 в буфере пакета
	.mask = mask, // сама маска
	.mask_size = mask_len, // длина маски
	.pattern = pattern } // чему должно быть равно
};
#endif

//------------------------------------------------------------------------------
LOCAL void fATRS(int argc, char *argv[])
{
    //_adapter *ad0 = rltk_wlan_info[0].dev;
	u8 channel = 1;
    if(argc > 1) {
    	channel = atoi(argv[1]);
        if((!channel) || channel > 14)  channel = 1;
        if (sniffer_run) {
        	sniffer_send_ena = 1;
        	if(wext_set_channel(WLAN0_NAME, channel) < 0) printf("\nSet chl %d error!\n\n", channel);
        	else printf("\nPromisc mode set chl %d\n\n", channel);
        	return;
        }
    }
    if(sniffer_run)  {
    	sniffer_run = 0;
    	sniffer_send_ena = 0;
		wifi_set_promisc(RTW_PROMISC_DISABLE, wifi_promisc_rx, 1);
#ifdef filter_num
		int i;
		for(i = filter_num; i > 0; i-- )
			wifi_disable_packet_filter(i);
		for(i = filter_num; i > 0; i-- )
			wifi_remove_packet_filter(i);
#endif
		sniffer_uart_deinit();
		printf("\nWiFi promisc mode disable\n\n");
	} else {
		sniffer_uart_init();
		enter_sniffer_mode(channel);
		/* enable all 802.11 packets*/
		wifi_set_promisc(RTW_PROMISC_ENABLE_2, wifi_promisc_rx, 1);
#ifdef filter_num
		wifi_init_packet_filter();
		int i;
		for(i = 1; i <= filter_num; i++ )
			wifi_add_packet_filter(i, &packet_filter[i-1], mask_mode);
		for(i = 1; i <= filter_num; i++ )
			wifi_enable_packet_filter(i);
#endif
    	sniffer_run = 1;
	}
}

//------------------------------------------------------------------------------
MON_RAM_TAB_SECTION COMMAND_TABLE console_commands_rwt[] = {
		{"ATRS", 0, fATRS, "[chl]: Sniffer WiFi Test"}
};


