/*
 * gpio_tst.c
 *      Author: pvvx
 */

#include "rtl8195a.h"
#include "rtl8195a/rtl_libc.h"

extern const uint8_t GPIO_PinMap_Chip2IP_8195a[92][2];
extern const uint16_t GPIO_PinMap_PullCtrl_8195a[92][3];
extern GPIO_PullCtrl_8195a(uint32_t chip_pin, int pull_type)



int	_GPIO_PullCtrl_8195a(int pin, int mode)
{
	uint16_t * ptr;

	ptr = &GPIO_PinMap_PullCtrl_8195a;
	while(*ptr != 0xffff)

}
