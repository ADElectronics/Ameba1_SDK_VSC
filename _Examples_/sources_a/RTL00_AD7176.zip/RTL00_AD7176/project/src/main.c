/*

 */

#include "device.h"
#include "diag.h"
#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "tcm_heap.h"
#include "hal_crypto.h"

extern void console_init(void);
extern void wifi_init(void);

#define FMAIN_ATTR

/* RAM/TCM/Heaps info */
void ShowMemInfo(void)
{
	DiagPrintf("\nCLK CPU\t\t%d Hz\nRAM heap\t%d bytes\nTCM heap\t%d bytes\n",
			HalGetCpuClk(), xPortGetFreeHeapSize(), tcm_heap_freeSpace());
}

const unsigned char cus_sig[32] = "Test";

void FMAIN_ATTR user_task(void) {
	wifi_init();
#if (defined(CONFIG_CRYPTO_STARTUP) && (CONFIG_CRYPTO_STARTUP))
	 if(rtl_cryptoEngine_init() != 0 ) {
		 error_printf("Crypto engine init failed!\n");
	 }
#else
//	 rtl_cryptoEngine_deinit();
#endif
	console_init();
	vTaskDelete(NULL);
}

int FMAIN_ATTR main(void) {
	printf("ResetCause: 0x%08x\n", HalGetResetCause());
	uint32_t * p = (uint32_t *)(SYSTEM_CTRL_BASE + REG_SYS_SYSTEM_CFG0);
	printf("SYSCFG 0..2: 0x%08x 0x%08x 0x%08x\n", p[0], p[1], p[2]);
	p = (uint32_t *)(SYSTEM_CTRL_BASE + REG_SYS_EFUSE_SYSCFG0);
	printf("EFUSE  0..3: 0x%08x 0x%08x 0x%08x 0x%08x\n", p[0], p[1], p[2], p[3]);
	printf("EFUSE  4..7: 0x%08x 0x%08x 0x%08x 0x%08x\n", p[4], p[5], p[6], p[7]);
	p = (uint32_t *)(SYSTEM_CTRL_BASE + REG_SYS_CLK_CTRL0);
	printf("CLK_CTRL 0..2: 0x%08x 0x%08x\n", p[0], p[1]);
	printf("PWR_CTRL: 0x%08x\n", HAL_SYS_CTRL_READ32(REG_SYS_PWR_CTRL));

	xTaskCreate(user_task, "UserInit", 1024, NULL, tskIDLE_PRIORITY + 0 + PRIORITIE_OFFSET, NULL);
	vTaskStartScheduler();
	return 0;
}



